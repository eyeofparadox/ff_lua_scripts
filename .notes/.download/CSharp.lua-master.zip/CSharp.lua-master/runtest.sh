#!/bin/sh
lua -i runtest.lua
