﻿using System;

namespace ILRuntimeTest.TestFramework
{
    [AttributeUsage(AttributeTargets.All)]
    public class TestCLRAttribute : Attribute
    {
        
    }
}