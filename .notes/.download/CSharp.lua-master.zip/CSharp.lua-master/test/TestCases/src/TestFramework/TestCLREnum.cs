﻿namespace ILRuntimeTest.TestFramework
{
    public enum TestCLREnum
    {
        Test1 = 0,
        Test2 = 1,
        Test3 = 2
    }
}