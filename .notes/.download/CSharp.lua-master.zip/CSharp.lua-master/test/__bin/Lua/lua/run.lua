function execute(cmd)
  print("execute", cmd)
  local code = os.execute(cmd)
  assert(code == 0)
end

local luaVersions = {
  { "LuaJIT-2.0.2", "__LUAJIT202__" },
  { "MoonJIT-2.2.0", "__MOONJIT220__" },
  { "Lua5.3", "__LUA53__" },
  { "Lua5.4", "__LUA54__" },
}

publishOutputDir = "bin/Debug/PublishOutput/"

local function publish(depth)
  local cmd = ("dotnet publish %s --configuration Debug --output %s"):format(("../"):rep(depth), publishOutputDir)
  execute(cmd)
end

local function deletePublishDir()
  local cmd = ("rd /s /q %s"):format("bin")
  execute(cmd)
end

local function compile(arg)
  local CSharpLua = publishOutputDir .. "CSharp.lua.Launcher.dll"
  local cmd = ("dotnet %s -s %s -d %s"):format(CSharpLua, arg.input, arg.output)
  if arg.libs then
    cmd = cmd .. " -l " .. arg.libs
  end
  if arg.metaFiles then
    cmd = cmd .. " -m " .. arg.metaFiles
  end
  if arg.attr then
    if arg.attr == true then
      cmd = cmd .. " -a"
    else
      cmd = cmd .. " -a " .. arg.attr
    end
  end
  if arg.metadata then
    cmd = cmd .. " -metadata"
  end
  if arg.classic then
    cmd = cmd .. " -c"
  end
  if arg.inlineProperty then
    cmd = cmd .. " -inline-property"
  end
  if arg.nodebug then
    cmd = cmd .. " -p"
  end
  if arg.module then
    cmd = cmd .. " -module"
  end
  if arg.extra then
    cmd = cmd .. " " .. arg.extra
  end
  execute(cmd)
end

local function launcher(arg, luaVersion)
  local luaPath = ("..\\"):rep(arg.depth - 1) .. "__bin\\"
  cmd = ("\"%s%s\\lua.exe\" %s"):format(luaPath, luaVersion, "launcher.lua")
  if arg.nodebug then
    cmd = cmd .. " nodebug"
  end
  execute(cmd)
end

local function runAll(t, args)
  for _, v in ipairs(luaVersions) do
    local define
    if type(v) == "table" then
      v, define = v[1], v[2]
    end
    print("--------------------", v, "--------------------")
    for _, arg in ipairs(args) do
      if v:find("JIT") then
        t.classic = true
        t.extra = "-csc /define:__JIT__;DEBUG"
      else
        t.classic = false
        t.extra = "-csc /define:DEBUG"
      end
      if define then
        t.extra = t.extra .. ';' .. define
      end
      arg.__index = arg
      setmetatable(t, arg)
      compile(t, v)
    end
    launcher(t, v)
  end
end

function run(args, ignoreBuild, afterPublishFn)
  if not ignoreBuild then
    execute("dotnet build --configuration Debug")
  end
  if args[1] == nil then
    args = { args }
  end
  publish(args.depth or args[1].depth)
  if afterPublishFn then
    afterPublishFn()
  end
  runAll({}, args)
  runAll({ inlineProperty = true }, args)
  runAll({ nodebug = true }, args)
  runAll({ inlineProperty = true, nodebug = true }, args)
  deletePublishDir()
end