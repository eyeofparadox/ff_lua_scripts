namespace Bridge.ClientTest.Utilities
{
    [Reflectable]
    internal class NotPublicClass
    {
    }
}