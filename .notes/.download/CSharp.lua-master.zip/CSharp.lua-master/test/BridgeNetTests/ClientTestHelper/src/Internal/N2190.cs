﻿namespace Bridge.ClientTestHelper
{
    public class N2190
    {
        internal static string Greeting()
        {
            return "Hi";
        }
    }
}