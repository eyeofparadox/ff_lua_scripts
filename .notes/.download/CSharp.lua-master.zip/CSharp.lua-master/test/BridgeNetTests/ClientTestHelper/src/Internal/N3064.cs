﻿namespace Bridge.ClientTestHelper
{
    [ObjectLiteral(ObjectInitializationMode.DefaultValue)]
    public class N3064
    {
        public int Number { get; set; }
    }
}