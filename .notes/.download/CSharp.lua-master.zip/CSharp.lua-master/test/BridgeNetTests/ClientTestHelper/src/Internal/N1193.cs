namespace Bridge.ClientTestHelper
{
    public static class N1193
    {
        public static string ClientTestHelperAssemblyVersion
        {
            get
            {
                return "1.0.0";
            }
        }
    }
}
